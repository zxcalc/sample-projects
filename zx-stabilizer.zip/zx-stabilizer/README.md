zx-project
==========

This is a Quantomatic project which contains all of the ZX-calculus axioms and
some useful theorems and simplification procedures. It also includes sample
graphs and derivations.
