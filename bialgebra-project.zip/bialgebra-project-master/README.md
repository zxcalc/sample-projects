# bialgebra-project

This is a Quantomatic project on bialgebras. It includes the necessary axioms, a simplification procedures which always produces unique normal forms and a sample graph with a derivation.
